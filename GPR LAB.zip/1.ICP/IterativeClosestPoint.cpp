#include <iostream>
#include <algorithm>
#include "IterativeClosestPoint.h"
#include <Eigen/Dense>
#include <Eigen/LU>
#include <glm/gtc/matrix_transform.hpp>
#include <math.h> 
#define PI 3.14159265
const int K_NEAR = 50;
const int MAX_DELTA_ALPHA = 40;
void IterativeClosestPoint::setClouds(PointCloud *pointCloud1, PointCloud *pointCloud2)
{
	cloud1 = pointCloud1;
	cloud2 = pointCloud2;
	knn.setPoints(&(cloud1->getPoints()));
}

// This method should mark the border points in cloud 1. It also changes their color (for example to red).
// You will need to add an attribute to this class that stores this property for all points in cloud 1. 

void IterativeClosestPoint::markBorderPoints()
{
	// TODO 
	vector<glm::vec3> &points = cloud1->getPoints();
	vector<glm::vec4> &colors = cloud1->getColors();
	borderPoints = vector<bool>(points.size(), false);
	
	NearestNeighbors neighbors;
	neighbors.setPoints(&points);
	for(int point_index = 0; point_index < points.size(); ++point_index)
	{
		//std::cout << "1" << std::endl;
		//1. Compute the centroid (center of mass) of the data points:
		glm::vec3 centroid(0,0,0);
		vector<size_t> current_neighborsIndex(K_NEAR);
		vector<glm::vec3> current_neighbors_aux(K_NEAR);
		vector<float> current_dists(K_NEAR);
		neighbors.getKNearestNeighbors(points[point_index], K_NEAR, current_neighborsIndex, current_dists);

		for(int i=0; i< K_NEAR;++i)
		{
			centroid.x += points[current_neighborsIndex[i]].x;
			centroid.y += points[current_neighborsIndex[i]].y;
			centroid.z += points[current_neighborsIndex[i]].z;
		}
		centroid.x = centroid.x/K_NEAR;
		centroid.y = centroid.y/K_NEAR;
		centroid.z = centroid.z/K_NEAR;

		//2. Translate all the points so that their origin is at centroid:
		//std::cout << "2" << std::endl;
		for(int i=0; i< K_NEAR;++i)
		{
			current_neighbors_aux[i] = points[current_neighborsIndex[i]] - centroid;
		}

		//3. Build the 3x3 covariance matrix:
		//std::cout << "3" << std::endl;
		Eigen::Matrix3f C;
		C << 0, 0, 0,
			 0, 0, 0,
			 0, 0, 0;
		for(int i=0; i< K_NEAR;++i)
		{
			C(0,0) += current_neighbors_aux[i].x*current_neighbors_aux[i].x;
			C(0,1) += current_neighbors_aux[i].x*current_neighbors_aux[i].y;
			C(0,2) += current_neighbors_aux[i].x*current_neighbors_aux[i].z;

			C(1,0) += current_neighbors_aux[i].y*current_neighbors_aux[i].x;
			C(1,1) += current_neighbors_aux[i].y*current_neighbors_aux[i].y;
			C(1,2) += current_neighbors_aux[i].y*current_neighbors_aux[i].z;

			C(2,0) += current_neighbors_aux[i].z*current_neighbors_aux[i].x;
			C(2,1) += current_neighbors_aux[i].z*current_neighbors_aux[i].y;
			C(2,2) += current_neighbors_aux[i].z*current_neighbors_aux[i].z;
		}

		//4. 
		//std::cout << "4" << std::endl;
		Eigen::SelfAdjointEigenSolver<Eigen::Matrix3f> eigensolver(C);
		/*std::cout << "the eigenvalues are: \n" << eigensolver.eigenvalues() << std::endl;
		std::cout << "the matrix is: \n " << eigensolver.eigenvectors() << std::endl;
		*/

		// Transform the k-nearest neighbors to this frame
		float current_neighborsAngles[K_NEAR];
		glm::vec3 v1(eigensolver.eigenvectors().col(2)(0),eigensolver.eigenvectors().col(2)(1),eigensolver.eigenvectors().col(2)(2));
		glm::vec3 v2(eigensolver.eigenvectors().col(1)(0),eigensolver.eigenvectors().col(1)(1),eigensolver.eigenvectors().col(1)(2));
		glm::vec3 v3(eigensolver.eigenvectors().col(0)(0),eigensolver.eigenvectors().col(0)(1),eigensolver.eigenvectors().col(0)(2));

	
		v1 = glm::normalize(v1);
		v2 = glm::normalize(v2);
		v3 = glm::normalize(v3);
		for(int i=0; i< K_NEAR;++i)
		{
			glm::vec3 vectorDiference = points[current_neighborsIndex[i]]-points[point_index];
			//vectorDiference = glm::normalize(vectorDiference);
			current_neighbors_aux[i].x = glm::dot(v1,vectorDiference);
			current_neighbors_aux[i].y = glm::dot(v2,vectorDiference);
			current_neighbors_aux[i].z = 0;
			current_neighborsAngles[i] = atan2(current_neighbors_aux[i].x,current_neighbors_aux[i].y)* 180 / PI;
			
		}
		std::sort(&current_neighborsAngles[0], &current_neighborsAngles[0] + K_NEAR, std::greater<float>());
		float max_difference =0;
		float prev_value = current_neighborsAngles[0];
		//std::cout << "NEXT " << std::endl;
		for(int i=1; i< K_NEAR;++i)
		{
			float curr_value = current_neighborsAngles[i];
			float difference = prev_value-curr_value;
			if(difference > max_difference)
				max_difference = difference;
			prev_value = curr_value;
			//std::cout << current_neighborsAngles[i] << std::endl;
		}
		if(current_neighborsAngles[0] > 0 && prev_value <0)
		{
			float angl1 = prev_value + 180;
			float angl2 = 180 - current_neighborsAngles[0];
			float difference = angl1+angl2;
			if(difference > max_difference)
				max_difference = difference;
		} 
		if(max_difference > MAX_DELTA_ALPHA)
		{
			//std::cout << "BORDER POINT DETECTED " << std::endl;
			borderPoints[point_index] = true;
			colors[point_index].x = 1.f;
			colors[point_index].y = 0.f;
			colors[point_index].z = 0.f;
			colors[point_index].w = 1.f;
		}
	}
	
}


// This method should compute the closest point in cloud 1 for all non border points in cloud 2. 
// This correspondence will be useful to compute the ICP step matrix that will get cloud 2 closer to cloud 1.
// Store the correspondence in this class as the following method is going to need it.
// As it is evident in its signature this method also returns the correspondence. The application draws this if available.

vector<int> *IterativeClosestPoint::computeCorrespondence()
{
	vector<glm::vec3> &pointsQ = cloud2->getPoints();
	vector<glm::vec3> &pointsP = cloud1->getPoints();
	correspondence = std::vector<int>(pointsQ.size(), -1); 
	vector<float> current_dists(1);
	vector<size_t> current_neighborsIndex(1);
	NearestNeighbors neighbors;
	neighbors.setPoints(&pointsP);
	for(int i=0; i< pointsQ.size(); ++i)
	{
		
		
		neighbors.getKNearestNeighbors(pointsQ[i], 1, current_neighborsIndex, current_dists);
		
		if(!borderPoints[current_neighborsIndex[0]])
			correspondence[i] = current_neighborsIndex[0];
	
	}
	return &correspondence;
}


// This method should compute the rotation and translation of an ICP step from the correspondence
// information between clouds 1 and 2. Both should be encoded in the returned 4x4 matrix.
// To do this use the SVD algorithm in Eigen.

glm::mat4 IterativeClosestPoint::computeICPStep()
{

//CALCULATE CENTROID
	vector<glm::vec3> &pointsP_all = cloud1->getPoints();					
	vector<glm::vec3> &pointsQ_all = cloud2->getPoints(); //cloud to move	
	
	
	vector<glm::vec3> pointsP;
	vector<glm::vec3> pointsQ;
	for(int i=0; i< pointsQ_all.size(); ++i)
	{
		if(correspondence[i] != -1)
		{
			pointsP.push_back(pointsP_all[correspondence[i]]);
			pointsQ.push_back(pointsQ_all[i]);
		}
		
	}
	int sizeCloud = pointsQ.size();
	glm::vec3 centroidQ(0,0,0);
	glm::vec3 centroidP(0,0,0);
	for(int i=0; i< sizeCloud;++i)
	{
		centroidQ.x += pointsQ[i].x;
		centroidQ.y += pointsQ[i].y;
		centroidQ.z += pointsQ[i].z;
	}
	for(int i=0; i< sizeCloud;++i)
	{
		centroidP.x += pointsP[i].x;
		centroidP.y += pointsP[i].y;
		centroidP.z += pointsP[i].z;
	}
	centroidP.x = centroidP.x/sizeCloud;
	centroidP.y = centroidP.y/sizeCloud;
	centroidP.z = centroidP.z/sizeCloud;
	centroidQ.x = centroidQ.x/sizeCloud;
	centroidQ.y = centroidQ.y/sizeCloud;
	centroidQ.z = centroidQ.z/sizeCloud;
	//std::cout << "CENTROID P" << std::endl;
	//std::cout << centroidP.x << " " <<centroidP.y  << " "<< centroidP.z<< std::endl;
	//std::cout << "CENTROID Q" << std::endl;
	//std::cout << centroidQ.x << " " <<centroidQ.y  << " "<< centroidQ.z<< std::endl;
   	
//CORRECT POINTS USING CENTROID
	Eigen::MatrixXf Q(sizeCloud,3);
	Eigen::MatrixXf P(sizeCloud,3);
	for(int i=0; i < sizeCloud;++i)
	{
		Q(i,0) = pointsQ[i].x - centroidQ.x;
		Q(i,1) = pointsQ[i].y - centroidQ.y;
		Q(i,2) = pointsQ[i].z - centroidQ.z;
	}
	for(int i=0; i < sizeCloud;++i)
	{
		P(i,0) = pointsP[i].x - centroidP.x;
		P(i,1) = pointsP[i].y - centroidP.y;
		P(i,2) = pointsP[i].z - centroidP.z;
	}

//COVARIANCE MATRIX
	Eigen::MatrixXf Cov = Q.transpose()*P;
//SVD
	Eigen::JacobiSVD<Eigen::MatrixXf> svd(Cov,Eigen::ComputeFullU | Eigen::ComputeFullV);
	
	Eigen::MatrixXf U = svd.matrixU();
    Eigen::MatrixXf V = svd.matrixV();
    Eigen::MatrixXf Vt = V.transpose();

    //Eigen::Matrix3f R = Vt.transpose()*U.transpose();
	Eigen::Matrix3f R = V*U.transpose();
    if (R.determinant() < 0 ){
        Vt.block<1,3>(2,0) *= -1;
        R = V*U.transpose();
    }
    Eigen::Vector3f centroidQ_eigen(centroidQ.x,centroidQ.y,centroidQ.z);
    Eigen::Vector3f centroidP_eigen(centroidP.x,centroidP.y,centroidP.z);
    Eigen::Vector3f t = centroidP_eigen - R*centroidQ_eigen;
   
    //std::cout << "TRANSLATION" << std::endl;
   	Eigen::Matrix4f T = Eigen::MatrixXf::Identity(4,4);
   	T.block<3,3>(0,0) = R;
    T.block<3,1>(0,3) = t;
   	glm::mat4 result;
   	//std::cout << t(0) << " " <<t(1)  << " "<< t(2)<< std::endl;
   	//std::cout << "TRANSFORM" << std::endl;
   	for (size_t i = 0; i < 4; ++i) {
        for (size_t j = 0; j < 4; ++j) {
            result[i][j] = T(j, i);
            //std::cout << " "<< result[i][j];
        }
        //std::cout << std::endl;
    }

   	return result;

	//return glm::mat4(1.0f);
}


// This method should perform the whole ICP algorithm with as many steps as needed.
// It should stop when maxSteps are performed, when the Frobenius norm of the transformation matrix of
// a step is smaller than a small threshold, or when the correspondence does not change from the 
// previous step.

vector<int> *IterativeClosestPoint::computeFullICP(unsigned int maxSteps)
{
	
	vector<int> oldCorrespondance;
	computeCorrespondence();
	oldCorrespondance = correspondence;
	bool first = true;
	for(int i=0; i < maxSteps; ++i)
	{
		glm::mat4 transform = computeICPStep();
		cloud2->transform(transform);
		computeCorrespondence();
		if(oldCorrespondance == correspondence)
			return &correspondence;
		oldCorrespondance = correspondence;

	}
	return &correspondence;
	

}





