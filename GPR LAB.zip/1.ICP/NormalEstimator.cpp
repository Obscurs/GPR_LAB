#include "NormalEstimator.h"
#include "NearestNeighbors.h"
#include <Eigen/Dense>
#include <iostream>
// This method has to compute a normal per point in the 'points' vector and put it in the 
// 'normals' vector. The 'normals' vector already has the same size as the 'points' vector. 
// There is no need to push_back new elements, only to overwrite them ('normals[i] = ...;')
// In order to compute the normals you should use PCA. The provided 'NearestNeighbors' class
// wraps the nanoflann library that computes K-nearest neighbors effciently. 


const int K_NEAR = 50;
void NormalEstimator::computePointCloudNormals(const vector<glm::vec3> &points, vector<glm::vec3> &normals)
{
	// TODO

	NearestNeighbors neighbors;
	neighbors.setPoints(&points);
	for(int point_index = 0; point_index < points.size(); ++point_index)
	{
		//std::cout << "1" << std::endl;
		//1. Compute the centroid (center of mass) of the data points:
		glm::vec3 centroid(0,0,0);
		vector<size_t> current_neighborsIndex(K_NEAR);
		vector<glm::vec3> current_neighbors_aux(K_NEAR);
		vector<float> current_dists(K_NEAR);
		neighbors.getKNearestNeighbors(points[point_index], K_NEAR, current_neighborsIndex, current_dists);

		for(int i=0; i< K_NEAR;++i)
		{
			centroid.x += points[current_neighborsIndex[i]].x;
			centroid.y += points[current_neighborsIndex[i]].y;
			centroid.z += points[current_neighborsIndex[i]].z;
		}
		centroid.x = centroid.x/K_NEAR;
		centroid.y = centroid.y/K_NEAR;
		centroid.z = centroid.z/K_NEAR;

		//2. Translate all the points so that their origin is at centroid:
		//std::cout << "2" << std::endl;
		for(int i=0; i< K_NEAR;++i)
		{
			current_neighbors_aux[i] = points[current_neighborsIndex[i]] - centroid;
		}

		//3. Build the 3x3 covariance matrix:
		//std::cout << "3" << std::endl;
		Eigen::Matrix3f C;
		C << 0, 0, 0,
			 0, 0, 0,
			 0, 0, 0;
		for(int i=0; i< K_NEAR;++i)
		{
			C(0,0) += current_neighbors_aux[i].x*current_neighbors_aux[i].x;
			C(0,1) += current_neighbors_aux[i].x*current_neighbors_aux[i].y;
			C(0,2) += current_neighbors_aux[i].x*current_neighbors_aux[i].z;

			C(1,0) += current_neighbors_aux[i].y*current_neighbors_aux[i].x;
			C(1,1) += current_neighbors_aux[i].y*current_neighbors_aux[i].y;
			C(1,2) += current_neighbors_aux[i].y*current_neighbors_aux[i].z;

			C(2,0) += current_neighbors_aux[i].z*current_neighbors_aux[i].x;
			C(2,1) += current_neighbors_aux[i].z*current_neighbors_aux[i].y;
			C(2,2) += current_neighbors_aux[i].z*current_neighbors_aux[i].z;
		}

		//4. 
		//std::cout << "4" << std::endl;
		Eigen::SelfAdjointEigenSolver<Eigen::Matrix3f> eigensolver(C);
		/*std::cout << "the eigenvalues are: \n" << eigensolver.eigenvalues() << std::endl;
		std::cout << "the matrix is: \n " << eigensolver.eigenvectors() << std::endl;
		*/


		//normals[point_index].x = eigensolver.eigenvectors().col(2)(0);
		//normals[point_index].y = eigensolver.eigenvectors().col(2)(1);
		//normals[point_index].z = eigensolver.eigenvectors().col(2)(2);

		//normals[point_index].x = eigensolver.eigenvectors().col(1)(0);
		//normals[point_index].y = eigensolver.eigenvectors().col(1)(1);
		//normals[point_index].z = eigensolver.eigenvectors().col(1)(2);

		normals[point_index].x = eigensolver.eigenvectors().col(0)(0);
		normals[point_index].y = eigensolver.eigenvectors().col(0)(1);
		normals[point_index].z = eigensolver.eigenvectors().col(0)(2);
		if(normals[point_index].z < 0)
		{
			normals[point_index] = -normals[point_index];
		}
		normals[point_index] = glm::normalize(normals[point_index]);
		//std::cout << "10" << std::endl;
	}
	
}


